const holes = document.querySelectorAll('.hole');
const scoreDisplay = document.getElementById('score');
const restartButton = document.getElementById('restartBtn');
let score = 0;
let gameActive = true;

function randomHole() {
    const randomIndex = Math.floor(Math.random() * holes.length);
    return holes[randomIndex];
}

function placeMoleOrBomb() {
    if (!gameActive) return;

    // Clear previous mole or bomb
    holes.forEach(hole => hole.classList.remove('mole', 'bomb'));

    const hole = randomHole();
    const type = Math.random() < 0.2 ? 'bomb' : 'mole';  // 20% chance to spawn a bomb

    hole.classList.add(type);

    // Set the mole to disappear after 1 second
    setTimeout(() => hole.classList.remove(type), 1000);
}

function handleHoleClick(event) {
    if (!gameActive) return;

    const hole = event.target;
    const type = hole.classList.contains('mole') ? 'mole' : (hole.classList.contains('bomb') ? 'bomb' : null);

    if (type === 'mole') {
        score++;
        scoreDisplay.textContent = score;
    } else if (type === 'bomb') {
        alert("Game Over! You clicked the bomb!");
        gameActive = false;
        scoreDisplay.textContent = "Game Over!";
    }
}

function restartGame() {
    score = 0;
    scoreDisplay.textContent = score;
    gameActive = true;
    placeMoleOrBomb();
}

// Event listeners
holes.forEach(hole => hole.addEventListener('click', handleHoleClick));
restartButton.addEventListener('click', restartGame);

// Start the game
setInterval(placeMoleOrBomb, 1500); // Mole/Bomb appears every 1.5 seconds
